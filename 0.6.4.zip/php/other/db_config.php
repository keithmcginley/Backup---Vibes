<?php

/*
 * All database connection variables
 */

//define('DB_USER', "root"); // db user
//define('DB_PASSWORD', "root"); // db password (mention your db password here)
//define('DB_DATABASE', "db1029802_sensus"); // database name
//define('DB_SERVER', "localhost"); // db server

define('DB_USER', "u1029802_sensus"); // db user
define('DB_PASSWORD', ">P<o,P2.qr"); // db password (mention your db password here)
define('DB_DATABASE', "db1029802_sensus"); // database name
define('DB_SERVER', "mysql2275int.cp.blacknight.com"); // db server
?>